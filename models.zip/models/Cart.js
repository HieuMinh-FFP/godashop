class Cart {
    fetch = (req) => {
        const cookie_cart = req.cookies.cart;

    }

}
module.exports = new Cart();
